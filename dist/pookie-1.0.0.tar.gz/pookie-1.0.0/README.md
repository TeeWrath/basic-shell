# Basic Python Shell for linux

pookie: A simple Python shell.
        Supports basic commands like
        - cd 
        - pwd 
        - ls 
        - clear
        - pookie
        - help 
        and external programs.